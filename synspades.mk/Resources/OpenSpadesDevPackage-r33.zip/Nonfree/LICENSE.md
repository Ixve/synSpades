
OpenSpades Non-GPL Pak License
==============================

Audio files: Copyright 2016 yvt, all rights reserved.

Model files: based on Ben Aksoy's Ace of Spades 0.75. (note: OpenSpades is a compatible game client of Ace of Spades 0.75)

Font files: See below

You may only redistribute this package in one or more of following means:

1. As a part of a binary or source distribution of OpenSpades or any derived, free download and free of charge, non-commercial open-source project.
2. As one or more separate packages to be installed on end users' system on the sole purpose to provide necessary game assets to a binary or source distribution of OpenSpades or any derived, free download and free of charge, non-commercial open-source project.
3. For private use.

You may NOT redistribute any audio files contained within the package separately.

This license notice shall be included in all copies of the package.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Fonts
-----

### SquareFont

SquareFont was created by Agustín Bou and is authorized to use for personal and commercial use.

### Alte DIN 1451 Mittelschrift Font Family

Alte DIN 1451 was created by Peter Wiegel, based on DIN 1451 German standard font.
Licensed under the [SIL Open Font License](http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL).

